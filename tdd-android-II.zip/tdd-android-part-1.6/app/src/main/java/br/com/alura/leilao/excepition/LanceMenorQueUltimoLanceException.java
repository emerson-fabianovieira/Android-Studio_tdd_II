package br.com.alura.leilao.excepition;

public class LanceMenorQueUltimoLanceException extends RuntimeException {
}
