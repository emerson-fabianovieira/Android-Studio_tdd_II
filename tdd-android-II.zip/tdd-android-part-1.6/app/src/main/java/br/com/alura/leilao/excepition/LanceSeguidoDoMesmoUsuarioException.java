package br.com.alura.leilao.excepition;

public class LanceSeguidoDoMesmoUsuarioException extends RuntimeException {
}
